package com.example.lms.model;

import java.time.LocalDate;

public class Loan {
    private Book borrowedBook;
    private User borrowingUser;
    private LocalDate borrowDate;
    private LocalDate returnDate;

    public Loan(Book borrowedBook, User borrowingUser, LocalDate borrowDate) {
        this.borrowedBook = borrowedBook;
        this.borrowingUser = borrowingUser;
        this.borrowDate = borrowDate;
        this.returnDate = null;
    }

    public Book getBorrowedBook() {
        return borrowedBook;
    }

    public User getBorrowingUser() {
        return borrowingUser;
    }

    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public boolean isActive() {
        return returnDate == null;
    }

    @Override
    public String toString() {
        String returnInfo = (returnDate != null) ? ", Returned: " + returnDate : ", Active";
        return "Book: '" + borrowedBook.getTitle() + "' (ISBN: " + borrowedBook.getISBN() +
               "), User: '" + borrowingUser.getName() + "' (ID: " + borrowingUser.getUserId() +
               "), Borrow Date: " + borrowDate + returnInfo;
    }
}