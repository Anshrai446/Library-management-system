package com.example.lms.model;

public class Book {
    private String title;
    private String author;
    private String ISBN;
    private int publicationYear;
    private String genre;
    private boolean isAvailable;

    public Book(String title, String author, String ISBN, int publicationYear, String genre) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.publicationYear = publicationYear;
        this.genre = genre;
        this.isAvailable = true;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getISBN() {
        return ISBN;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public String getGenre() {
        return genre;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    @Override
    public String toString() {
        return "Title: " + title + ", Author: " + author + ", ISBN: " + ISBN +
               ", Year: " + publicationYear + ", Genre: " + genre +
               ", Available: " + (isAvailable ? "Yes" : "No");
    }
}