package com.example.lms;

import com.example.lms.service.Library;
import com.example.lms.util.InputHandler;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InputHandler inputHandler = new InputHandler(scanner);
        Library library = new Library();

        System.out.println("Welcome to the Console Library Management System!");

        while (true) {
            displayMenu();
            int choice = inputHandler.getIntegerInput("Enter your choice: ");

            switch (choice) {
                case 1:
                    String title = inputHandler.getStringInput("Enter book title: ");
                    String author = inputHandler.getStringInput("Enter book author: ");
                    String isbn = inputHandler.getStringInput("Enter book ISBN: ");
                    int pubYear = inputHandler.getIntegerInput("Enter publication year: ");
                    String genre = inputHandler.getStringInput("Enter book genre: ");
                    library.addBook(title, author, isbn, pubYear, genre);
                    break;
                case 2:
                    String userId = inputHandler.getStringInput("Enter user ID: ");
                    String name = inputHandler.getStringInput("Enter user name: ");
                    library.addUser(userId, name);
                    break;
                case 3:
                    String borrowUserId = inputHandler.getStringInput("Enter user ID: ");
                    String borrowIsbn = inputHandler.getStringInput("Enter book ISBN to borrow: ");
                    library.borrowBook(borrowUserId, borrowIsbn);
                    break;
                case 4:
                    String returnIsbn = inputHandler.getStringInput("Enter book ISBN to return: ");
                    library.returnBook(returnIsbn);
                    break;
                case 5:
                    library.displayAllBooks();
                    break;
                case 6:
                    library.displayAvailableBooks();
                    break;
                case 7:
                    library.displayAllUsers();
                    break;
                case 8:
                    String userBooksId = inputHandler.getStringInput("Enter user ID to view borrowed books: ");
                    library.displayBorrowedBooksByUser(userBooksId);
                    break;
                case 9:
                    String bookSearchQuery = inputHandler.getStringInput("Enter title, author, or ISBN to search for books: ");
                    library.searchBooks(bookSearchQuery);
                    break;
                case 10:
                    String userSearchQuery = inputHandler.getStringInput("Enter user ID or name to search for users: ");
                    library.searchUsers(userSearchQuery);
                    break;
                case 0:
                    System.out.println("Exiting Library Management System. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println("\nPress Enter to continue...");
            inputHandler.getStringInput("");
        }
    }

    private static void displayMenu() {
        System.out.println("\n--- Library Menu ---");
        System.out.println("1. Add New Book");
        System.out.println("2. Add New User");
        System.out.println("3. Borrow Book");
        System.out.println("4. Return Book");
        System.out.println("5. Display All Books");
        System.out.println("6. Display Available Books");
        System.out.println("7. Display All Users");
        System.out.println("8. View Books Borrowed by User");
        System.out.println("9. Search Books");
        System.out.println("10. Search Users");
        System.out.println("0. Exit");
        System.out.println("--------------------");
    }
}