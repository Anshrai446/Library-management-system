package com.example.lms.service;

import com.example.lms.model.Book;
import com.example.lms.model.User;
import com.example.lms.model.Loan;
import com.example.lms.util.Validator;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Library {
    private List<Book> books;
    private List<User> users;
    private List<Loan> loans;

    public Library() {
        this.books = new ArrayList<>();
        this.users = new ArrayList<>();
        this.loans = new ArrayList<>();
        seedData();
    }

    private void seedData() {
        addBook("The Hobbit", "J.R.R. Tolkien", "9780345339683", 1937, "Fantasy");
        addBook("1984", "George Orwell", "9780451524935", 1949, "Dystopian");
        addBook("To Kill a Mockingbird", "Harper Lee", "9780446310789", 1960, "Fiction");
        addUser("U001", "Alice Johnson");
        addUser("U002", "Bob Williams");
    }

    public void addBook(String title, String author, String isbn, int pubYear, String genre) {
        if (!Validator.isNotNullOrEmpty(title) || !Validator.isNotNullOrEmpty(author) || !Validator.isNotNullOrEmpty(isbn) || !Validator.isNotNullOrEmpty(genre)) {
            System.out.println("Error: All book fields must be provided.");
            return;
        }
        if (!Validator.isValidISBN(isbn)) {
            System.out.println("Error: Invalid ISBN format. (Expected 10 or 13 digits, optionally with hyphens or X)");
            return;
        }
        if (!Validator.isValidYear(pubYear)) {
            System.out.println("Error: Invalid publication year.");
            return;
        }
        if (getBookByIsbn(isbn) != null) {
            System.out.println("Error: Book with ISBN '" + isbn + "' already exists.");
            return;
        }
        books.add(new Book(title, author, isbn, pubYear, genre));
        System.out.println("Book '" + title + "' added successfully.");
    }

    public void addUser(String userId, String name) {
        if (!Validator.isNotNullOrEmpty(userId) || !Validator.isNotNullOrEmpty(name)) {
            System.out.println("Error: User ID and Name cannot be empty.");
            return;
        }
        if (getUserByUserId(userId) != null) {
            System.out.println("Error: User with ID '" + userId + "' already exists.");
            return;
        }
        users.add(new User(userId, name));
        System.out.println("User '" + name + "' added successfully.");
    }

    public Book getBookByIsbn(String isbn) {
        return books.stream()
                     .filter(b -> b.getISBN().equalsIgnoreCase(isbn))
                     .findFirst()
                     .orElse(null);
    }

    public User getUserByUserId(String userId) {
        return users.stream()
                    .filter(u -> u.getUserId().equalsIgnoreCase(userId))
                    .findFirst()
                    .orElse(null);
    }

    public void borrowBook(String userId, String isbn) {
        User user = getUserByUserId(userId);
        Book book = getBookByIsbn(isbn);

        if (user == null) {
            System.out.println("Error: User with ID '" + userId + "' not found.");
            return;
        }
        if (book == null) {
            System.out.println("Error: Book with ISBN '" + isbn + "' not found.");
            return;
        }
        if (!book.isAvailable()) {
            System.out.println("Error: Book '" + book.getTitle() + "' is currently not available.");
            return;
        }

        book.setAvailable(false);
        loans.add(new Loan(book, user, LocalDate.now()));
        System.out.println("Book '" + book.getTitle() + "' borrowed by '" + user.getName() + "'.");
    }

    public void returnBook(String isbn) {
        Book book = getBookByIsbn(isbn);

        if (book == null) {
            System.out.println("Error: Book with ISBN '" + isbn + "' not found.");
            return;
        }
        if (book.isAvailable()) {
            System.out.println("Error: Book '" + book.getTitle() + "' was not borrowed or has already been returned.");
            return;
        }

        Optional<Loan> activeLoan = loans.stream()
                                         .filter(l -> l.getBorrowedBook().getISBN().equalsIgnoreCase(isbn) && l.isActive())
                                         .findFirst();

        if (activeLoan.isPresent()) {
            activeLoan.get().setReturnDate(LocalDate.now());
            book.setAvailable(true);
            System.out.println("Book '" + book.getTitle() + "' returned successfully.");
        } else {
            System.out.println("Error: No active loan found for book with ISBN '" + isbn + "'.");
        }
    }

    public void displayAllBooks() {
        if (books.isEmpty()) {
            System.out.println("No books in the library.");
            return;
        }
        System.out.println("\n--- All Books ---");
        books.forEach(System.out::println);
        System.out.println("-----------------");
    }

    public void displayAvailableBooks() {
        List<Book> availableBooks = books.stream()
                                        .filter(Book::isAvailable)
                                        .collect(Collectors.toList());
        if (availableBooks.isEmpty()) {
            System.out.println("No books currently available.");
            return;
        }
        System.out.println("\n--- Available Books ---");
        availableBooks.forEach(System.out::println);
        System.out.println("-----------------------");
    }

    public void displayAllUsers() {
        if (users.isEmpty()) {
            System.out.println("No users registered.");
            return;
        }
        System.out.println("\n--- All Users ---");
        users.forEach(System.out::println);
        System.out.println("-----------------");
    }

    public void displayBorrowedBooksByUser(String userId) {
        User user = getUserByUserId(userId);
        if (user == null) {
            System.out.println("Error: User with ID '" + userId + "' not found.");
            return;
        }

        List<Loan> userLoans = loans.stream()
                                    .filter(l -> l.getBorrowingUser().getUserId().equalsIgnoreCase(userId) && l.isActive())
                                    .collect(Collectors.toList());

        if (userLoans.isEmpty()) {
            System.out.println("User '" + user.getName() + "' has no active borrowed books.");
            return;
        }

        System.out.println("\n--- Books borrowed by " + user.getName() + " ---");
        userLoans.forEach(loan -> System.out.println(loan.getBorrowedBook().getTitle() + " (Borrowed on: " + loan.getBorrowDate() + ")"));
        System.out.println("------------------------------------");
    }

    public void searchBooks(String query) {
        if (!Validator.isNotNullOrEmpty(query)) {
            System.out.println("Error: Search query cannot be empty.");
            return;
        }
        List<Book> foundBooks = books.stream()
                .filter(book -> book.getTitle().toLowerCase().contains(query.toLowerCase()) ||
                                 book.getAuthor().toLowerCase().contains(query.toLowerCase()) ||
                                 book.getISBN().equalsIgnoreCase(query))
                .collect(Collectors.toList());

        if (foundBooks.isEmpty()) {
            System.out.println("No books found matching '" + query + "'.");
        } else {
            System.out.println("\n--- Search Results for '" + query + "' ---");
            foundBooks.forEach(System.out::println);
            System.out.println("------------------------------------");
        }
    }

    public void searchUsers(String query) {
        if (!Validator.isNotNullOrEmpty(query)) {
            System.out.println("Error: Search query cannot be empty.");
            return;
        }
        List<User> foundUsers = users.stream()
                .filter(user -> user.getName().toLowerCase().contains(query.toLowerCase()) ||
                                 user.getUserId().equalsIgnoreCase(query))
                .collect(Collectors.toList());

        if (foundUsers.isEmpty()) {
            System.out.println("No users found matching '" + query + "'.");
        } else {
            System.out.println("\n--- Search Results for '" + query + "' ---");
            foundUsers.forEach(System.out::println);
            System.out.println("------------------------------------");
        }
    }
}