package com.example.lms.util;

import java.time.LocalDate;

public class Validator {

    public static boolean isNotNullOrEmpty(String str) {
        return str != null && !str.trim().isEmpty();
    }

    public static boolean isValidISBN(String isbn) {
        if (!isNotNullOrEmpty(isbn)) {
            return false;
        }
        String cleanedIsbn = isbn.replace("-", "").trim();
        if (cleanedIsbn.length() == 10) {
            return cleanedIsbn.matches("[0-9]{9}[0-9X]");
        } else if (cleanedIsbn.length() == 13) {
            return cleanedIsbn.matches("[0-9]{13}");
        }
        return false;
    }

    public static boolean isValidYear(int year) {
        int currentYear = LocalDate.now().getYear();
        return year > 1000 && year <= currentYear + 1;
    }
}